﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Ports;
using System.Data;
using System.Windows.Forms;

namespace InventoryMSystem
{
    public class SerialPortBase
    {
        private Timer _precisionTimer;
        private int _precision = 500;
        private SerialPort _serialPort = null;
        private DataTable _dataTable = null;
        public SerialPortBase(SerialPort sp)
        {
            this._serialPort = sp;
            this._dataTable = new DataTable("data");
            this._precisionTimer=new Timer();
            this._precisionTimer.Tick += new EventHandler(_precisionTimer_Tick);
            this._precisionTimer.Interval = this._precision;
        }
        public void Start()
        {
            if (this._serialPort != null)
            {
                if (!this._serialPort.IsOpen)
                {
                    this._serialPort.Open();
                }
                this._precisionTimer.Start();
            }
        }
        void _precisionTimer_Tick(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }
        public virtual void initialDataTable()
        {

        }
        public virtual void parseData(byte[] bytes)
        {

        }
    }
}
