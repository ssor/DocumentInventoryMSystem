﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;


namespace InventoryMSystem
{
    public class DocumentFile
    {
        public string name;
        public int floorNumber;//柜子编号
        public Button doc;
        public static int DOCUMENT_WIDTH = 16;
        public static int DOCUMENT_HEIGHT = 92;
        public int Left;
        public int Top;
        public DocumentFile(string name, int floor)
        {
            this.doc = new Button();
            this.doc.Width = DocumentFile.DOCUMENT_WIDTH;
            this.doc.Height = DocumentFile.DOCUMENT_HEIGHT;
            this.doc.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.doc.BackgroundImage = global::InventoryMSystem.Properties.Resources.DocFile;
            this.doc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.doc.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.doc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.doc.Name = name;
            this.doc.UseVisualStyleBackColor = false;
            this.name = name;
            this.floorNumber = floor;
        }
        public void setDocPosition(int left, int top)
        {
            this.doc.Left = left;
            this.doc.Top = top;
        }
    }
    // 柜子的层
    public class CarbinetFloor
    {
        public int floor_height = 104;
        //保存添加的档案
        public List<DocumentFile> documentList = new List<DocumentFile>();
        public int floorNumber;
        public int left = 40;
        public int top = 33;
        public static int DOCUMENT_GAP = 2;//档案间的间隔
        System.Windows.Forms.Control.ControlCollection controls;
        List<DocumentChair> chairsList = new List<DocumentChair>();

        public CarbinetFloor(int floorNumber, System.Windows.Forms.Control.ControlCollection controls)
        {
            this.floorNumber = floorNumber;
            this.controls = controls;
        }
        public void AddDoc(DocumentFile Doc)
        {
            //检查是否已经存在了
            bool bExist = false;
            foreach (DocumentFile df in this.documentList)
            {
                if (Doc.name == df.name)
                {
                    bExist = true;
                    break;
                }
            }
            if (bExist)//存在的将不再重复添加
            {
                return;
            }
            //int left = this.documentList.Count * (CarbinetFloor.DOCUMENT_GAP + DocumentFile.STATIC_WIDTH);

            DocumentChair dc = null;
            if (this.chairsList.Count <= this.documentList.Count)//坑的数量至少和档案数量相同，数量相同的时候，要添加新坑
            {
                //每增加一个档案需要为档案增加一个位置
                dc = new DocumentChair();
                dc.index = this.documentList.Count;
                dc.floor = this.floorNumber;
                this.chairsList.Add(dc);
            }
            else
            {
                //坑的数量多于档案的数量，说明有坑是空的
                foreach (DocumentChair d in this.chairsList)
                {
                    Debug.WriteLine(string.Format("isEmpty -> {0}    {1}   {2}", d.floor, d.index, d.getEmptyState()));
                    if (d.getEmptyState())
                    {
                        dc = d;
                        break;
                    }
                }
            }

            Debug.WriteLine(string.Format("*** AddDoc *** {0}  {1}   ", Doc.name, Doc.floorNumber));
            Debug.WriteLine(string.Format("*** chair -> {0}   Doc -> {1}", this.chairsList.Count, this.documentList.Count));
            //档案添加到每层的列表中
            this.documentList.Add(Doc);
            //根据坑设置档案的位置
            //Doc.setDocPosition(left + this.left, this.top + 33);
            //Doc.setDocPosition(dc.Left+this.left, CarbinetFloor.FLOOR_HEIGHT - DocumentFile.DOCUMENT_HEIGHT);
            Doc.setDocPosition(dc.Left + this.left, this.top + this.floor_height - DocumentFile.DOCUMENT_HEIGHT);
            dc.setEmptyState(false);//坑已被占用

            //Debug.WriteLine(string.Format("left -> {0} top -> {1}", dc.Left, this.top));
            this.controls.Add(Doc.doc);
        }
        public void RemoveDoc(DocumentFile doc,int i)
        {
            this.controls.Remove(doc.doc);
            this.documentList.Remove(doc);
            //this.chairsList[i].setEmptyState(true);
            this.chairsList.Remove(this.chairsList[i]);
        }
    }
    //柜子类
    //每个柜子有四层，每层可以添加一定数目的档案
    public class Carbinet
    {
        #region member

        int floorCount = 4;
        public int Left = 100;
        int top = 30;

        //保存form的控件集合
        System.Windows.Forms.Control.ControlCollection controlArray = null;
        //柜子的层
        List<CarbinetFloor> floors = new List<CarbinetFloor>();
        #endregion
        public Carbinet(System.Windows.Forms.Control.ControlCollection controlA)
        {
            this.controlArray = controlA;
        }
        public void ConfigFloor(int floorCount)
        {
            this.floorCount = floorCount;

            CarbinetFloor cf = new CarbinetFloor(1, this.controlArray);
            //int top = cf.floor_height * this.floors.Count;
            cf.top = 0;
            cf.floor_height = 130;
            cf.left = this.Left;
            this.floors.Add(cf);
            cf = new CarbinetFloor(2, this.controlArray);
            cf.top = 130;
            cf.floor_height = 110;
            cf.left = this.Left;
            this.floors.Add(cf);
            //for (int i = 1; i <= floorCount; i++)
            //{
            //    CarbinetFloor cf = new CarbinetFloor(i, this.controlArray);
            //    int top = cf.floor_height * this.floors.Count;
            //    cf.top = top;
            //    this.floors.Add(cf);
            //}
        }
        // 向柜子的指定层添加档案文件
        public void AddDocFile(string name, int floor)
        {
            DocumentFile df = new DocumentFile(name, floor);
            this.AddDocFile(df);
        }
        public void AddDocFile(DocumentFile Doc)
        {
            foreach (CarbinetFloor cf in this.floors)
            {
                if (cf.floorNumber == Doc.floorNumber)
                {
                    cf.AddDoc(Doc);
                    break;
                }
            }
        }
        public void RemoveDocFile(string docName)
        {
            bool bFinded = false;
            foreach (CarbinetFloor cf in this.floors)
            {
                for (int i = 0; i < cf.documentList.Count; i++)
                {
                    if (cf.documentList[i].name == docName)
                    {
                        cf.RemoveDoc(cf.documentList[i],i);
                        bFinded = true;
                        break;
                    }
                    if (bFinded)
                    {
                        break;
                    }
                }
            }
        }
    }

    public class DocumentChair
    {
        bool IsEmpty = true;

        int left;

        public int Left
        {
            //序列号 与 前面档案数目加间隔的乘积
            get { return this.index * (CarbinetFloor.DOCUMENT_GAP + DocumentFile.DOCUMENT_WIDTH); }
            set { left = value; }
        }
        public int index = 0;//
        public int floor = 0;

        public void setEmptyState(bool flag)
        {
            this.IsEmpty = flag;
            Debug.WriteLine(string.Format("setEmptyState -> {0} {1} {2}",this.floor,this.index, flag));
        }
        public bool getEmptyState()
        {
            return this.IsEmpty;
        }
    }
}
