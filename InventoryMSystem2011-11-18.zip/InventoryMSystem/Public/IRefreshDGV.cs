﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMSystem
{
    public interface IRefreshDGV
    {
       void refreshDGV();
    }
}
